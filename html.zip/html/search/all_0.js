var searchData=
[
  ['_5f_5finit_5f_5f',['__init__',['../classtt_1_1_boid.html#a7f2375c14463c9db1e4f979711df0e54',1,'tt::Boid']]]
];
