var searchData=
[
  ['random_5fstart',['random_start',['../classtt_1_1_boid.html#a81c49fc92a613f2f6d3184f9ff6587be',1,'tt::Boid']]],
  ['rule1',['rule1',['../classtt_1_1_boid.html#a66693a5cfd3472b06846505a58026657',1,'tt::Boid']]],
  ['rule2',['rule2',['../classtt_1_1_boid.html#a30d518c7257d2251b0cb51c23015209d',1,'tt::Boid']]],
  ['rule3',['rule3',['../classtt_1_1_boid.html#abe009e8c75ccd8f9f01227c28258c463',1,'tt::Boid']]]
];
